# 3D_Viewer Restorable BM_CII Overlay Package

This ZIP is structured like a GitHub repository overlay. Extract it anywhere, then copy `repo-overlay/` into a clean `reallaksh19/3D_Viewer` checkout.

## What is included

### `repo-overlay/`
Files intended to be copied into the repo root.

Key paths:

```text
viewer/test/bm-cii/latest/BM_CII_latest_engineering.glb
viewer/test/bm-cii/inputxml-actual/BM_CII_inputxml_actual_engineering.glb
viewer/test/bm-cii/component-metadata/BM_CII_component_metadata_fixed_engineering.glb
viewer/benchmarks/bm-cii/latest-glb-manifest.json
viewer/benchmarks/bm-cii/BM_CII_ISONOTE_sideload.csv/json
viewer/benchmarks/bm-cii/BM_CII_LINE_NO_sideload.csv/json
benchmarks/bm-cii/BM_CII_ISONOTE_sideload.csv/json
benchmarks/bm-cii/BM_CII_LINE_NO_sideload.csv/json
doc/Supportlogic.md
```

### `artifacts/`
Generated GLB history, source inputs, reports, JSON audits, and patch/source-like materials from the sandbox.

### `restore_scripts/`
Convenience scripts:

```bash
cd /path/to/3D_Viewer
bash /path/to/3D_Viewer_restorable_overlay/restore_scripts/install_overlay.sh
```

PowerShell:

```powershell
cd C:\path	oD_Viewer
powershell -ExecutionPolicy Bypass -File C:\path	oD_Viewer_restorable_overlayestore_scripts\install_overlay.ps1
```

## Current latest GLB

The default BM_CII latest GLB in `repo-overlay` is from:

```text
BM_CII_v69_IsonoteAxialResolver/BM_CII_Enriched_v69_isonote_axial_resolver_engineering.glb
```

InputXML actual reference GLB is from:

```text
BM_CII_v68_InputXmlAxialResolver/BM_CII_Enriched_v68_inputxml_axial_resolver_engineering.glb
```

Component metadata fixed reference GLB is from:

```text
BM_CII_v63_ComponentMetadataFixed/BM_CII_Enriched_v63_component_metadata_fixed_engineering.glb
```

## Important limitation

This package is built from the files available in the ChatGPT sandbox under `/mnt/data`. It is a restorable overlay of generated artifacts, benchmark data, rules documentation, and patch/source-like files. It is not a full Git history clone of `reallaksh19/3D_Viewer`.

## Recommended restore flow

1. Clone or open a clean repo checkout.
2. Install overlay.
3. Check changes with `git status`.
4. Commit as a repo asset/data/documentation restore.
5. Keep actual app source changes under normal PR review.
