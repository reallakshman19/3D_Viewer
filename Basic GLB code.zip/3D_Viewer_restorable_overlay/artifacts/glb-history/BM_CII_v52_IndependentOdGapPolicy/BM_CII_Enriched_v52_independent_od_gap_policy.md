# BM_CII v52 — Independent OD/GAP placement policy

- InputXML Basic only
- No transformation
- No ISONOTE
- No Temp1
- Independent module logic: family renderer decides symbol, then OD/GAP policy decides contact point.

```text
If abs(dot(applied restraint axis, pipe tangent)) >= 0.92:
  restraint is parallel to pipe
  move arrow line to any lateral pipe axis by OD/2
If GAP > 0:
  move arrow head away from pipe by GAP * 10mm
```

| Node | BM_CII item | Family | Axis (Pipe Axis basis) | Cosine | GAP | Parallel? | Gap offset | Expected GLB symbol | OD/GAP contact policy |
| ---: | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | ANC | ANCHOR | AXIAL / FLOW-BLOCKING | PLANE BLOCKING THE FLOW | None | False | 0.000000 | Flat plate blocking flow | anchor / no arrow |
| 35 | +Y | REST | VERTICAL | VERTICAL AXIS | -1.0101 | False | 0.000000 | Single axis arrow toward +Y | non-parallel: head at P - radial(direction)*(OD/2); positive GAP moves outward on same radial axis |
| 35 | X | AXIS RESTRAINT | AXIAL | X | -1.0101 | False | 0.000000 | Axis pair along X | non-parallel: head at P - radial(direction)*(OD/2); positive GAP moves outward on same radial axis |
| 35 | Z | AXIS RESTRAINT | AXIAL | Z | -1.0101 | True | 0.000000 | Axis pair along Z; parallel to pipe so arrow line is laterally offset | parallel-to-pipe: move restraint arrow line to lateral OD/2 axis; positive GAP moves farther outward on same lateral axis |
| 130 | +Z | LINESTOP / DIRECTIONAL STOP | AXIAL | +Z | -1.0101 | True | 0.000000 | Single axial arrow toward +Z; parallel to pipe so arrow line is laterally offset | parallel-to-pipe: move restraint arrow line to lateral OD/2 axis; positive GAP moves farther outward on same lateral axis |
| 190 | ANC | ANCHOR | AXIAL / FLOW-BLOCKING | PLANE BLOCKING THE FLOW | None | False | 0.000000 | Flat plate blocking flow | anchor / no arrow |
| 205 | LIM | LIMIT | AXIAL | AXIAL TO PIPE | -1.0101 | True | 0.000000 | Axial pair; parallel to pipe so arrow line is laterally offset | parallel-to-pipe: move restraint arrow line to lateral OD/2 axis; positive GAP moves farther outward on same lateral axis |
| 205 | Y | REST | VERTICAL | VERTICAL AXIS | -1.0101 | False | 0.000000 | Axis pair along Y | non-parallel: head at P - radial(direction)*(OD/2); positive GAP moves outward on same radial axis |
| 205 | HANGER | HANGER / SPRING | LATERAL / VERTICAL HANGER | VERTICAL AXIS | -1.0101 | False | 0.000000 | Coil only, no arrow | coil only; if GAP>0 coil reference moves outward from CIRCUM_TOP |
| 240 | ANC | ANCHOR | AXIAL / FLOW-BLOCKING | PLANE BLOCKING THE FLOW | None | False | 0.000000 | Flat plate blocking flow | anchor / no arrow |
| 255 | GUIDE | GUIDE | LATERAL | X (own TYPE=7 RESTRAINT XCOSINE=1) | -1.0101 | False | 0.000000 | GUIDE lateral pair selected from own restraint cosine | guide: selected own-restraint cosine lateral axis; tips at OD/2; positive GAP moves farther outward |
| 255 | +Y | REST | VERTICAL | VERTICAL AXIS | -1.0101 | False | 0.000000 | Single axis arrow toward +Y | non-parallel: head at P - radial(direction)*(OD/2); positive GAP moves outward on same radial axis |

Rendered: 12 / 12
Skipped: 0