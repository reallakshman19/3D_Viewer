# BM_CII v59 — Readable 3D Node Label Boards

InputXML Basic only. No ISONOTE. No Temp1. No transformation.

Base support GLB: `BM_CII_Enriched_v52_independent_od_gap_policy_engineering.glb`

## RCA addressed

v58 cross-billboard stroke text was portable but unreadable because two perpendicular copies overlapped in common camera angles. v59 disables cross-billboard text and exports one clear high-contrast 3D label board per node.

## Node annotation contract

- Marker at exact node centreline coordinate.
- Ring marker around node point.
- Leader line without arrowhead.
- Real 3D label board, not CSS2D-only.
- High-contrast tube stroke text on a dark board.
- Cross-billboard duplicate text disabled to avoid overlap.

## Nodes rendered

| Node | Marker | Leader | Label | Geometry mode | Face | External viewer safe |
|---:|---|---|---|---|---|---|
| 10 | node-10-marker | node-10-leader | N10 | single-readable-3d-label-board | +Z | True |
| 35 | node-35-marker | node-35-leader | N35 | single-readable-3d-label-board | +Z | True |
| 130 | node-130-marker | node-130-leader | N130 | single-readable-3d-label-board | +Z | True |
| 190 | node-190-marker | node-190-leader | N190 | single-readable-3d-label-board | +Z | True |
| 205 | node-205-marker | node-205-leader | N205 | single-readable-3d-label-board | +Z | True |
| 240 | node-240-marker | node-240-leader | N240 | single-readable-3d-label-board | +Z | True |
| 255 | node-255-marker | node-255-leader | N255 | single-readable-3d-label-board | +Z | True |

## Counts

```text
Node annotations: 7
Support base: v52 independent OD/GAP support glyphs
Rendered supports in base: 12
Skipped supports in base: 0
```
