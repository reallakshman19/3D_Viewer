# BM_CII v62 — Line No Sideload UI Benchmark

Base GLB: v61 ISONOTE readable boards.

This run adds node-wise Line No side-load data and viewer property-panel resolution logic.
The GLB geometry is unchanged from v61; the property panel resolves Line No at runtime from the sideload dataset.

## Line No sideload data

| Node | Line No | Scope |
|---:|---|---|
| 10 | LINE XYZ | topology-carry-forward; component-properties-only |

## Expected component property panel

For component `PE_003_PIPE_30_TO_35`, if the selected component is topologically connected downstream of Node 10:

- `Line No.: LINE XYZ`
- `Line No Source: BM_CII mock line-no sideload; propagated through component topology`
- `Line No Anchor Node: 10`
- `Line No Scope: node-wise sideload topology carry-forward`

This rule is explicitly not applied to supports/restraints.
