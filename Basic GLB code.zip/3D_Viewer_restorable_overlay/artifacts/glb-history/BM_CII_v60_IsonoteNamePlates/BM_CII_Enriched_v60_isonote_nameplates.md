# BM_CII v60 — ISONOTE Name Plates

Input GLB: `/mnt/data/BM_CII_latest_chat/BM_CII_latest_engineering.glb`

Adds node-wise sideloaded ISONOTE name plates as real GLB geometry.

## Rules

- Source text is used as provided, node-wise.
- ISONOTE is an annotation layer, not support/restraint geometry.
- No CSS2D dependency.
- No cross-billboard duplicate text.
- Node labels/support symbols retained from latest accepted GLB.

## ISONOTE records

| Node | ISONOTE |
|---:|---|
| 35 | `:/PS-123 :ISONOTE 'REST(28kN), GUIDE(6kN),LINE STOP(15kN)'` |
| 130 | `:ISONOTE 'REST NOT DEFINED, SINGLE AXIS Z'` |
| 255 | `:ISONOTE 'REST(3kN), GUIDE(1kN)'` |
| 205 | `:/PS-456 :ISONOTE 'REST(10kN), HOLDDOWN,LINE STOP(6kN), Holddown without Guide Can Spring'` |

Geometry records: 4

Output: `BM_CII_Enriched_v60_isonote_nameplates_engineering.glb`
