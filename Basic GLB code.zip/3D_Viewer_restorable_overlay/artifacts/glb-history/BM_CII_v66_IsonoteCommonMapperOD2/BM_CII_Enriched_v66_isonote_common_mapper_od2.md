# BM_CII v66 — ISONOTE common-mapper OD/2 restraint GLB

This artifact applies the approved master mapping table. ISONOTE text is converted into normalized synthetic support records and rendered using the common InputXML support-mapper contract and OD/2 placement policy.

## Locked rules

- REST always +Y vertical upward arrow
- HOLDDOWN double vertical arrows ±Y
- GUIDE horizontal X-pipe => Z lateral; horizontal Z-pipe => X lateral; vertical pipe => X/Z four arrows
- LINE STOP and LIMIT/LIM default to ± axial if no explicit sign
- SINGLE AXIS without +/- => warning/popup-required neutral marker
- Can Spring / Spring Can => coil warning below pipe
- OD/2 policy applied to all symbols

## Node-wise synthetic records

| Node | ISONOTE | Synthetic records |
|---:|---|---|
| 35 | `:/PS-123 :ISONOTE 'REST(28kN), GUIDE(6kN),LINE STOP(15kN)'` | REST / VERTICAL / Y / + / REST<br>GUIDE / LATERAL / X / ± / GUIDE<br>LINE_STOP / AXIAL / PIPE_AXIAL / ± / LINE_STOP |
| 130 | `:ISONOTE 'REST NOT DEFINED, SINGLE AXIS Z'` | NEGATION_REST / N/A / N/A / N/A / SUPPRESS_REST<br>AXIS_RESTRAINT_UNRESOLVED / UNRESOLVED_AXIS / Z / UNKNOWN / WARNING_POPUP |
| 255 | `:ISONOTE 'REST(3kN), GUIDE(1kN)'` | REST / VERTICAL / Y / + / REST<br>GUIDE / LATERAL / X / ± / GUIDE |
| 205 | `:/PS-456 :ISONOTE 'REST(10kN), HOLDDOWN,LINE STOP(6kN), Holddown without Guide Can Spring'` | REST / VERTICAL / Y / + / REST<br>HOLDDOWN / VERTICAL / Y / ± / HOLDDOWN<br>LINE_STOP / AXIAL / PIPE_AXIAL / ± / LINE_STOP<br>NEGATION_GUIDE / N/A / N/A / N/A / SUPPRESS_GUIDE<br>SPRING_WARNING / BELOW_PIPE / Y / WARNING / SPRING_WARNING |

## Files

- GLB: `/mnt/data/BM_CII_v66_IsonoteCommonMapperOD2/BM_CII_Enriched_v66_isonote_common_mapper_od2_engineering.glb`
- JSON: `/mnt/data/BM_CII_v66_IsonoteCommonMapperOD2/BM_CII_Enriched_v66_isonote_common_mapper_od2.json`