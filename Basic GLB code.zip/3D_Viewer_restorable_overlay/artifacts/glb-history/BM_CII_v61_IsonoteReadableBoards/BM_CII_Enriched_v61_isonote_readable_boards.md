# BM_CII v61 — ISONOTE readable boards

Base GLB: `/mnt/data/BM_CII_latest_chat/BM_CII_latest_engineering.glb`

ISONOTE boards are node-label-style 3D readable geometry, not white placeholders.

| Node | ISONOTE | Wrapped lines |
|---:|---|---|
| 35 | `:/PS-123 :ISONOTE 'REST(28kN), GUIDE(6kN),LINE STOP(15kN)'` | 3 |
| 130 | `:ISONOTE 'REST NOT DEFINED, SINGLE AXIS Z'` | 2 |
| 255 | `:ISONOTE 'REST(3kN), GUIDE(1kN)'` | 2 |
| 205 | `:/PS-456 :ISONOTE 'REST(10kN), HOLDDOWN,LINE STOP(6kN), Holddown without Guide Can Spring'` | 4 |

Output: `BM_CII_Enriched_v61_isonote_readable_boards_engineering.glb`
SHA256: `d50cbce32b7a0096c9462a2503286980c4611bcca64fc688bced58caa61fe68e`
Size: 2341272 bytes
