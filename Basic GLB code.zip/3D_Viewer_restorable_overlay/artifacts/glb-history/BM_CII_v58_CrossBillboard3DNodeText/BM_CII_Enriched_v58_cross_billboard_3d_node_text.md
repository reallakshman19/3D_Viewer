# BM_CII v58 — Cross-Billboard 3D Node Text

InputXML Basic only. No ISONOTE. No Temp1. No transformation.

Base support GLB: `BM_CII_Enriched_v52_independent_od_gap_policy_engineering.glb`

## RCA addressed

CSS2D node labels are not portable to external GLB viewers. Single flat static plates become backside/edge-on slivers. v58 exports real 3D stroke-text geometry duplicated on two perpendicular text planes, so labels are visible in external GLB viewers and in Basic GLB/PCF without relying on CSS2D.

## Node annotation contract

- Marker at exact node centreline coordinate.
- Ring marker around node point.
- Leader line without arrowhead.
- Portable 3D stroke text `N<node>`.
- Cross-billboard text planes: `+Z` and `+X`.
- No static blue label plates.
- No CSS2D-only dependency.
- Annotation geometry remains separate from support/restraint symbols.

## Nodes rendered

| Node | Marker | Leader | Label | Text planes | Static plates | External viewer safe |
|---:|---|---|---|---|---:|---|
| 10 | node-10-marker | node-10-leader | N10 | +Z, +X | 0 | True |
| 35 | node-35-marker | node-35-leader | N35 | +Z, +X | 0 | True |
| 130 | node-130-marker | node-130-leader | N130 | +Z, +X | 0 | True |
| 190 | node-190-marker | node-190-leader | N190 | +Z, +X | 0 | True |
| 205 | node-205-marker | node-205-leader | N205 | +Z, +X | 0 | True |
| 240 | node-240-marker | node-240-leader | N240 | +Z, +X | 0 | True |
| 255 | node-255-marker | node-255-leader | N255 | +Z, +X | 0 | True |

## Counts

```text
Node annotations: 7
Support base: v52 independent OD/GAP support glyphs
Rendered supports in base: 12
Skipped supports in base: 0
```
