# BM_CII v67 — ISONOTE visual cleanup

## Changes

- Reduced misleading LINE STOP circular plates/rings to 42% of previous size.
- Changed unresolved SINGLE AXIS warning triangle to light red/pink.
- Added a visible exclamation mark inside the warning triangle.
- Kept geometry as GLB-side meshes; no repo code change in this run.

## Affected nodes

- Node 35: LINE STOP circular plates reduced.
- Node 205: LINE STOP circular plates reduced.
- Node 130: warning triangle changed to light red/pink with `!` marker.

## Files

- GLB: `BM_CII_Enriched_v67_isonote_visual_cleanup_engineering.glb`
- Audit: `BM_CII_Enriched_v67_isonote_visual_cleanup.json`
