# BM_CII v65 - ISONOTE routed OD rules

Generated GLB with the new requested rules applied as an artifact only.

## Rule additions

1. `Can Spring` / `Spring Can` / `Can spring` creates a spring warning coil below the pipe.
2. `Single` without explicit `+`/`-` axis sign adds a warning marker and sets `popupRequired=true` metadata.
3. ISONOTE expected restraint glyphs are treated as routed through the common support-mapper / OD policy contract, not a separate support path.

## Node 205 spring rule

Source note:

```text
:/PS-456 :ISONOTE 'REST(10kN), HOLDDOWN,LINE STOP(6kN), Holddown without Guide Can Spring'
```

Action:

```text
Can Spring detected => coil warning marker moved below pipe.
```

Old coil bounds: `[[-1.2596, 0.0494, -1.1458], [-1.168, 0.2812, -1.0542]]`

New coil bounds: `[[-1.2596, -0.4306, -1.1458], [-1.168, -0.1988, -1.0542]]`

## Node 130 single-axis rule

Source note:

```text
:ISONOTE 'REST NOT DEFINED, SINGLE AXIS Z'
```

Action:

```text
Single axis Z detected without +Z/-Z sign.
Added warning triangle and metadata popupRequired=true.
No + or - sign was assumed.
```

Warning glyph bounds:

```json
[
  {
    "node": "BM_CII_ISONOTE_WARNING_node_130_SINGLE_AXIS_Z_SIGN_REQUIRED",
    "bounds": [
      [
        -0.3066,
        0.23,
        -4.449
      ],
      [
        -0.1334,
        0.38,
        -4.431
      ]
    ]
  },
  {
    "node": "BM_CII_ISONOTE_WARNING_node_130_exclamation_bar",
    "bounds": [
      [
        -0.228,
        0.2625,
        -4.435
      ],
      [
        -0.212,
        0.3275,
        -4.419
      ]
    ]
  },
  {
    "node": "BM_CII_ISONOTE_WARNING_node_130_exclamation_dot",
    "bounds": [
      [
        -0.234,
        0.211,
        -4.441
      ],
      [
        -0.206,
        0.239,
        -4.413
      ]
    ]
  },
  {
    "node": "BM_CII_ISONOTE_WARNING_node_130_leader",
    "bounds": [
      [
        -0.2219,
        0.0565,
        -4.444
      ],
      [
        0.0019,
        0.1835,
        -4.436
      ]
    ]
  }
]
```

## No code change

This run generated a GLB artifact only. Repository source was not modified.
