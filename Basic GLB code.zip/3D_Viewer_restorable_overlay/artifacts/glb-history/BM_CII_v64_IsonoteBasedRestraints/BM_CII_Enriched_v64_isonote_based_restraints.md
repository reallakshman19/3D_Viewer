# BM_CII v64 — ISONOTE-Based Restraints GLB
Generated in chat only. No repository code fix was made.
## Source rule
Restraint visuals are generated from the sideloaded ISONOTE text as-is, not from InputXML RESTRAINT rows. Existing InputXML support glyphs are removed from the active scene root.
## Node-wise generated restraints
### Node 35
ISONOTE: `:/PS-123 :ISONOTE 'REST(28kN), GUIDE(6kN),LINE STOP(15kN)'`
Generated:
- REST +Y 28kN
- GUIDE X pair 6kN
- LINE_STOP Z pair 15kN

### Node 130
ISONOTE: `:ISONOTE 'REST NOT DEFINED, SINGLE AXIS Z'`
Generated:
- SINGLE_AXIS_Z +Z only
- REST intentionally not generated

### Node 255
ISONOTE: `:ISONOTE 'REST(3kN), GUIDE(1kN)'`
Generated:
- REST +Y 3kN
- GUIDE X pair 1kN

### Node 205
ISONOTE: `:/PS-456 :ISONOTE 'REST(10kN), HOLDDOWN,LINE STOP(6kN), Holddown without Guide Can Spring'`
Generated:
- REST +Y 10kN
- HOLDDOWN top plate/down arrow
- LINE_STOP X pair 6kN
- SPRING_WARNING coil
- GUIDE intentionally not generated due to "without Guide"

## Important notes
- Node 130: `REST NOT DEFINED` generates no REST symbol; only single-axis Z is shown.
- Node 205: `without Guide` is treated literally; no GUIDE symbol is generated. The spring warning coil is generated from the phrase `Can Spring`.
- Visual layer metadata: `supports.isonote_restraints`.
