# CAESAR support source + arrow-only rendering patch

This patch starts coding the support/restraint bugs identified in the review.

Bug fixes targeted:
1. Bulky block-style restraints are replaced by simple arrow-only support symbols.
2. Support rendering now has a source selector:
   - inputxml
   - isonote
3. InputXML mode renders only XML restraints / hangers.
4. ISONOTE mode renders only virtual supports parsed from ISONOTE comments.
5. No default mixing of XML supports and ISONOTE supports.
6. CAESAR TYPE=0 remains UNKNOWN_TYPE0 and is not mapped to ANCHOR.
7. Old support enhancer is skipped for the new arrow-only support symbols.
8. Regression test verifies both modes and generated arrow symbols.

Configuration:
  supportRendering: {
    source: "inputxml" // "inputxml" | "isonote"
  }

Accepted aliases:
  supportRenderSource
  supportRenderingSource
  supportRendering.source

Files changed:
- viewer/js/pcf2glb/glb/buildExportScene.js
- viewer/js/pcf2glb/glb/buildComponentObject.js
- viewer/js/pcf2glb/glb/enhanceSupportDirectionProxyReferenceV2.js
- viewer/js/pcf2glb/glb/caesar/CaesarSupportRenderingCore.js
- viewer/tests/caesar-support-rendering-source.test.js

Apply:
  git apply caesar_support_source_arrow_core.patch

Run:
  node viewer/tests/caesar-support-rendering-source.test.js

Integration note:
If the earlier CaesarGlbCore patches are already applied, do not call multiple preprocessors
directly from buildExportScene.js. Compose them in the core pipeline:

  1. topology/bend/tee trimming
  2. support source selection + arrow-only rendering
  3. annotation/ISONOTE panels

This support patch should replace the older bulky restraint rendering path.
