# CAESAR restraint/support core patch

This patch targets the pending "Restraint / support" bucket.

It adds a production-oriented restraint core that:
1. Enriches support records before mesh creation.
2. Resolves support node from NODE / AT_NODE / SUPPORT_NODE or nearest pipe node.
3. Builds a local support frame:
   - CAESAR restraint axis -> GLB axis
   - pipe tangent at support node
   - normal/side vectors
4. Keeps CAESAR TYPE=0 unresolved as UNKNOWN_TYPE0. It is not forced to ANCHOR.
5. Renders CAESAR-style support symbols using the local frame:
   - REST
   - GUIDE
   - LINESTOP
   - LIMIT / HOLDDOWN
   - ANCHOR
   - SPRING / HANGER
   - SHOE
   - UNKNOWN_TYPE0
6. Prevents the older support enhancer from re-hiding/replacing the v3 restraint symbols.
7. Adds regression coverage.

Files changed:
- viewer/js/pcf2glb/glb/buildExportScene.js
- viewer/js/pcf2glb/glb/buildComponentObject.js
- viewer/js/pcf2glb/glb/enhanceSupportDirectionProxyReferenceV2.js
- viewer/js/pcf2glb/glb/caesar/CaesarRestraintCore.js
- viewer/tests/caesar-restraint-core.test.js

Apply:
  git apply caesar_restraint_core_logic.patch

Run:
  node viewer/tests/caesar-restraint-core.test.js

Important integration note:
If you have already applied the previous caesar_glb_core_logic.patch, merge the
prepareCaesarRestraintCoreModel() call into CaesarGlbCore.js instead of running
two independent preprocessors from buildExportScene.js.
