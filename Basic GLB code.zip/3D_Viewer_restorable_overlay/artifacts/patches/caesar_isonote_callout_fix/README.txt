# ISONOTE unreadable text fix — numbered callouts

Bug from v7 snap:
- Annotation text is still not readable in Don McCurdy / generic GLB viewer.
- Canvas/textured full ISONOTE panels are not reliable enough as portable GLB labels.

Fix:
1. Default ISONOTE annotation mode is changed to numbered callouts.
2. Full ISONOTE text is no longer rendered directly inside the GLB by default.
3. GLB shows small yellow numbered bubbles only:
   - 1, 2, 3, 4
4. Full note text is preserved in:
   - root.userData.caesarAnnotationCallouts
   - each callout object's userData.caesarCalloutText
   - raw/component attributes
5. Each bubble is readable from both sides using front/back geometry.
6. Object count is reduced versus panel text/pixel glyphs.
7. Panel mode remains available for debug:
   caesarAnnotation.mode = "panel"

New default:
  caesarAnnotation: {
    mode: "callout",
    isonoteMaxNodes: 4,
    maxNodeLabels: 18,
    showFullIsonoteTextInGlb: false
  }

Files changed:
- viewer/js/pcf2glb/glb/buildExportScene.js
- viewer/js/pcf2glb/glb/buildComponentObject.js
- viewer/js/pcf2glb/glb/caesar/CaesarAnnotationCore.js
- viewer/tests/caesar-isonote-callout.test.js

Apply after:
- caesar_annotation_core_logic.patch
- caesar_annotation_presentation_fix.patch
- caesar_isonote_backside_fix.patch

Apply:
  git apply caesar_isonote_callout_fix.patch

Run:
  node viewer/tests/caesar-isonote-callout.test.js

Expected visual result:
- No unreadable large text cards in generic GLB viewer.
- Small numbered yellow bubbles at ISONOTE nodes.
- Full text available in GLB userData/sidecar/report.
