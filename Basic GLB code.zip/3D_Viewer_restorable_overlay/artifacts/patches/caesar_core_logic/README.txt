# CAESAR GLB core logic patch

This patch introduces a topology-first core layer for InputXML -> GLB.

Scope covered:
1. Central CAESAR GLB core preprocessing entry point.
2. Topology graph and node classification.
3. Bend trimming before mesh creation.
4. Explicit bend arc components.
5. Tee/olet nodes protected from accidental elbow rendering.
6. Restraint frame enrichment with raw CAESAR cosine -> GLB axis metadata.
7. Regression test for bend trimming, tee protection, and restraint frame enrichment.

Patch files:
- viewer/js/pcf2glb/glb/buildExportScene.js
- viewer/js/pcf2glb/glb/buildComponentObject.js
- viewer/js/pcf2glb/glb/caesar/CaesarGlbCore.js
- viewer/js/pcf2glb/glb/caesar/CaesarMathCore.js
- viewer/js/pcf2glb/glb/caesar/CaesarTopologyCore.js
- viewer/js/pcf2glb/glb/caesar/CaesarBendTrimCore.js
- viewer/js/pcf2glb/glb/caesar/CaesarRestraintFrameCore.js
- viewer/tests/caesar-glb-core-geometry.test.js

Apply:
  git apply caesar_glb_core_logic.patch

Run:
  node viewer/tests/caesar-glb-core-geometry.test.js

Then regenerate BM_CII_Enriched_engineering GLB.
