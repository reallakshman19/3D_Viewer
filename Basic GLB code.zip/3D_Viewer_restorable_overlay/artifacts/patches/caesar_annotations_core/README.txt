# CAESAR annotation / ISONOTE core patch

This patch targets the pending "Annotation / ISONOTE" bucket.

It adds a core annotation layer before mesh creation.

What it does:
1. Reads ISONOTE from:
   - model.isonotes / model.isoNotes
   - model.annotations / model.nodeAnnotations
   - options.isonotes / options.nodeAnnotations
   - component attributes: ISONOTE, ISONTE, ISO_NOTE, CAESAR_ISONOTE, ANNOTATION, NODE_NOTE
2. Groups notes node-wise and removes duplicates.
3. Creates one CAESAR_ANNOTATION_PANEL per ISONOTE node.
4. Creates readable CAESAR_NODE_LABEL_CARD cards for key benchmark nodes.
5. Removes duplicate legacy NODE_LABEL records for generated nodes unless keepLegacyNodeLabels=true.
6. Renders:
   - yellow/black ISONOTE panels
   - short yellow leader line to source node
   - blue/white node label cards
   - short blue leader line to source node
7. Stores caesarAnnotationCoreStats in GLB root userData.
8. Adds regression test.

Files changed:
- viewer/js/pcf2glb/glb/buildExportScene.js
- viewer/js/pcf2glb/glb/buildComponentObject.js
- viewer/js/pcf2glb/glb/caesar/CaesarAnnotationCore.js
- viewer/tests/caesar-annotation-core.test.js

Apply:
  git apply caesar_annotation_core_logic.patch

Run:
  node viewer/tests/caesar-annotation-core.test.js

Important integration note:
If caesar_glb_core_logic.patch and caesar_restraint_core_logic.patch are already
applied, do not call three independent preprocessors from buildExportScene.js.
Instead, compose them in this order inside CaesarGlbCore.js:

  1. topology / bend / tee trim
  2. restraint frame enrichment
  3. annotation panel generation

Reason:
Annotations should be generated after geometry and restraint positions are final.
