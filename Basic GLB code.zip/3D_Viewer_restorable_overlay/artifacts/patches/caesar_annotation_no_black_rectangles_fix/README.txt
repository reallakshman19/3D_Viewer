# CAESAR annotation no-black-rectangles fix

Bug:
- Black rectangles / dark annotation boards are still visible in generic GLB viewer.
- These rectangles hide the model and make annotation feel heavier than pipe/support geometry.

Fix:
1. Default node label style changed to circular "bubble", not rectangular card.
2. Default max node labels reduced to 10.
3. ISONOTE remains numbered callout mode by default.
4. Full text panels remain available only when explicitly requested with mode="panel".
5. Header-band/shadow flags default to false.
6. Node labels no longer use rectangular texture-card/background by default.
7. ISONOTE callouts and node labels use circular front/back bubble geometry.
8. Adds test to ensure no shadow/background/header/texture-card rectangle is generated in default callout/bubble mode.

New defaults:
  caesarAnnotation: {
    mode: "callout",
    nodeLabelStyle: "bubble",
    maxNodeLabels: 10,
    removeBlackRectangles: true,
    showPanelShadow: false,
    showPanelHeaderBand: false
  }

Files changed:
- viewer/js/pcf2glb/glb/caesar/CaesarAnnotationCore.js
- viewer/tests/caesar-annotation-no-black-rectangles.test.js

Apply after:
- caesar_annotation_core_logic.patch
- caesar_annotation_presentation_fix.patch
- caesar_isonote_backside_fix.patch
- caesar_isonote_callout_fix.patch

Apply:
  git apply caesar_annotation_no_black_rectangles_fix.patch

Run:
  node viewer/tests/caesar-annotation-no-black-rectangles.test.js

Expected visual result:
- No black rectangular note boards.
- ISONOTE shown as yellow numbered circular callouts.
- Node labels shown as small blue/white circular bubbles.
- Full note text kept in userData/sidecar/report, not rendered as GLB rectangles by default.
