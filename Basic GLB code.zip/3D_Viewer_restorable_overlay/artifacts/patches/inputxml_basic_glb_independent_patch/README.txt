# InputXML -> Basic GLB independent converter patch

Adds a separate Model Converter option:

  Model converter > InputXML -> Basic GLB

This is intentionally independent from the existing rich InputXML->GLB path.

## No-overlap rule

The new Basic GLB path does not import or call:
- viewer/converters/inputxml-dxf/InputXmlBranchExtractor.js
- viewer/converters/inputxml-glb/inputxml-to-glb-runner.js
- viewer/js/pcf2glb/glb/buildExportScene.js
- rich CAESAR annotation/support modules

It only uses:
- three
- three/addons/exporters/GLTFExporter.js

The GLB exporter helper is copied into the new path.

## Added files

- viewer/converters/inputxml-basic-glb/InputXmlBasicParser.js
- viewer/converters/inputxml-basic-glb/InputXmlBasicSceneBuilder.js
- viewer/converters/inputxml-basic-glb/InputXmlBasicGlbExporter.js
- viewer/converters/inputxml-basic-glb/inputxml-basic-glb-runner.js
- viewer/tabs/model-converters/converters/inputxml-to-basic-glb.js
- viewer/tabs/model-converters/inputxml-basic-glb-bridge.js
- viewer/tests/inputxml-basic-glb-independent.test.js

## Changed file

- viewer/tabs/model-converters-tab.js

## Output

For sample.XML, the converter outputs:

- sample-basic.glb
- sample-basic-glb-sidecar.json

## Basic visual scope

- PIPINGELEMENT pipe cylinders
- simple bend-as-cylinder proxy
- simple valve box marker
- simple flange ring marker
- simple tee/olet node marker
- optional node dots
- optional XML restraint/hanger arrows

## Apply

```bash
git apply inputxml_basic_glb_independent.patch
```

## Test

```bash
node viewer/tests/inputxml-basic-glb-independent.test.js
```

Status: patch created; not applied to GitHub branch; tests not run in repo checkout.
