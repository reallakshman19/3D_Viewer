# ISONOTE backside / reversed-card fix

Bug:
- ISONOTE text/card appears from the back side in Don McCurdy / generic GLB viewers.
- DoubleSide material is not enough for text because the back face can appear mirrored
  or the user initially sees the non-intended side of the label.

Fix:
1. Orient the nominal annotation front outward from its leader/source node.
2. Replace single DoubleSide card with two independent FrontSide planes:
   - one front plane
   - one back plane rotated 180 degrees
3. Disable depth test/write on annotation card materials.
4. Add polygon offset to reduce z-fighting.
5. Apply same double-sided-text logic to node label cards.
6. Add regression test.

Files changed:
- viewer/js/pcf2glb/glb/caesar/CaesarAnnotationCore.js
- viewer/tests/caesar-isonote-backside.test.js

Apply after:
- caesar_annotation_core_logic.patch
- caesar_annotation_presentation_fix.patch

Apply:
  git apply caesar_isonote_backside_fix.patch

Run:
  node viewer/tests/caesar-isonote-backside.test.js

Expected visual result:
- ISONOTE card readable from both sides.
- No mirrored/back-side text when rotating model in external GLB viewer.
