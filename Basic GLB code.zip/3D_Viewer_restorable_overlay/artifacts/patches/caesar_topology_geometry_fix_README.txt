# CAESAR topology geometry fix

This patch adds a topology post-processor before GLB scene creation.

Fixes:
- Prevents elbow arcs being created/kept at tee/olet/branch nodes.
- Converts explicit CAESAR bend rows into an incoming trimmed pipe leg plus a synthetic bend arc.
- Trims the outgoing straight pipe away from the bend vertex to stop straight pipe penetration through elbows.
- Adds explicit curve point support to buildElbowMesh().
- Stores post-process stats in GLB root userData.

Apply:
  git apply caesar_topology_geometry_fix.patch

Then run the BM_CII InputXML->GLB benchmark and inspect:
- node 30, 70, 100, 140, 150: no accidental elbows at tee/olet nodes
- bend corners: straight pipes stop at tangent points before elbow arcs
