# CAESAR annotation presentation fix

This patch addresses the v6 snap finding:

"geometry improved, but annotation layer is now the main failure."

Bugs fixed:
1. Large black / dark annotation slabs removed.
2. Separate dark header-band removed.
3. ISONOTE panels made compact.
4. ISONOTE leader length reduced.
5. Node labels made smaller and brighter.
6. Default node labels reduced from many benchmark nodes to key nodes.
7. ISONOTE panels capped to 4 nodes by default.
8. Text is rendered as one canvas texture per panel/card where browser canvas is available.
9. Node label / ISONOTE text no longer explodes into hundreds of pixel-mesh glyphs in browser mode.
10. Fallback pixel text remains for non-browser tests or environments without canvas.

New options:
  caesarAnnotation: {
    isonoteMaxNodes: 4,
    maxNodeLabels: 18,
    compactCards: true,
    useCanvasTexture: true,
    removeLegacyLabels: true
  }

Files changed:
- viewer/js/pcf2glb/glb/caesar/CaesarAnnotationCore.js
- viewer/tests/caesar-annotation-presentation.test.js

Apply after the annotation core patch:
  git apply caesar_annotation_presentation_fix.patch

Run:
  node viewer/tests/caesar-annotation-presentation.test.js

Expected visual result:
- No large black cross/slab cards blocking the model.
- 4 compact yellow ISONOTE cards max by default.
- Smaller blue/white node labels.
- Shorter leaders.
- Lower object/hint count in Don McCurdy viewer.
