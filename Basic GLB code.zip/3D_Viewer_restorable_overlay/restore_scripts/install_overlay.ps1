# Install repo overlay into the current 3D_Viewer checkout.
# Usage: cd C:\path\to\3D_Viewer; powershell -ExecutionPolicy Bypass -File C:\path\to\restore_scripts\install_overlay.ps1
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PkgRoot = Split-Path -Parent $ScriptDir
$Overlay = Join-Path $PkgRoot "repo-overlay"
if (!(Test-Path $Overlay)) { throw "repo-overlay not found next to restore_scripts" }
Copy-Item -Path (Join-Path $Overlay "*") -Destination (Get-Location) -Recurse -Force
Write-Host "Overlay installed. Review changes with: git status; git diff --stat"
Write-Host "BM_CII latest GLB path: viewer/test/bm-cii/latest/BM_CII_latest_engineering.glb"
