#!/usr/bin/env bash
set -euo pipefail
# Install repo overlay into the current 3D_Viewer checkout.
# Usage: cd /path/to/3D_Viewer && bash /path/to/restore_scripts/install_overlay.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
if [ ! -d "$PKG_ROOT/repo-overlay" ]; then
  echo "repo-overlay not found next to restore_scripts" >&2
  exit 1
fi
cp -a "$PKG_ROOT/repo-overlay/." .
echo "Overlay installed. Review changes with: git status && git diff --stat"
echo "BM_CII latest GLB path: viewer/test/bm-cii/latest/BM_CII_latest_engineering.glb"
